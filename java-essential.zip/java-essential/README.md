# java-essential

## Building
```
git clone git@github.com:hyunsik-mentor/java-essential.git
cd java-essential
./gradlew build
```
