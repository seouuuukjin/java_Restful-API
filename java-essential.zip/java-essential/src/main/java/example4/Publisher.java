package example4;

import example3.Book;

public interface Publisher {
    String getName();

    void publish(Book book);
}
