package example4.package1;

public class Class1 {
    example4.package1.Class1 abc;
}
