package example4;

import java.util.List;

public class AbcPublisherClient {

    public static class BookDescription {
        BookDescription(String title, List<String> authors, String isbn) {
            // something
        }
    }

    public void publish(BookDescription book) {
        // something
    }
}
