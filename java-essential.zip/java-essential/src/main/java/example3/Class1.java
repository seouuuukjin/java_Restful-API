package example3;

import example3.Class1;

public class Class1 {
    Class1 abc;
}
