package default_constructor;

public abstract class Bird {
    public Bird() {
        System.out.println("Bird::new() is called");
    }
}
